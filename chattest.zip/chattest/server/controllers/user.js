userRouter = require("express").Router();

// Doing CRUD with user in mongodb

const User = require("../models/user");

userRouter.post("", (req, res) => {
  const user = new User({
    username: req.body.username,
    email: req.body.email,
    password: req.body.password,
  });
  user.save().then((data) => {
    res.send(data);
  });
  // .catch((err) => {
  //   res.status(500).send({
  //     message: err.message || "Some error occurred while creating the User.",
  //   });
  // });
});

module.exports = userRouter;
